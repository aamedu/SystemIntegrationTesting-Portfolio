import junit.framework.Test;
import junit.framework.TestSuite;

public class ERMS {

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTestSuite(LOGIN.class);
    suite.addTestSuite(STORE CREATION.class);
    suite.addTestSuite(REQUEST INITIATION.class);
    suite.addTestSuite(First level Approval (Sina).class);
    suite.addTestSuite(Second Level Approver (Akosa).class);
    suite.addTestSuite(Third Level Approver (Osilama).class);
    suite.addTestSuite(Fourth Level Approver (Chukwuma).class);
    suite.addTestSuite(Fifth Level Approver (Odum).class);
    suite.addTestSuite(Request Initiation.class);
    suite.addTestSuite(CS Rep.class);
    suite.addTestSuite(Procurement Approval/ Allocation.class);
    suite.addTestSuite(Allocation Approval.class);
    suite.addTestSuite(Asset Transfer.class);
    suite.addTestSuite(Transfer Receipt.class);
    suite.addTestSuite(Quote Preparation.class);
    suite.addTestSuite(Quote Approval.class);
    suite.addTestSuite(Quote Submission.class);
    suite.addTestSuite(Bid Rating.class);
    suite.addTestSuite(Bid Approval (Bili Odum).class);
    suite.addTestSuite(Make Order.class);
    suite.addTestSuite(Accept/Reject LPO.class);
    suite.addTestSuite(Invoice Creation.class);
    suite.addTestSuite(Invoice Approval (Oyekemi).class);
    suite.addTestSuite(Invoice Approval (Chinwe.nwabugwu).class);
    suite.addTestSuite(Acounting Entries.class);
    return suite;
  }

  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
}
