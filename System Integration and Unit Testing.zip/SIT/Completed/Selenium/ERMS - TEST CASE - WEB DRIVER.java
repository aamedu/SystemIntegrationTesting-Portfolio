package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class ERMSTESTCASEWEBDRIVER {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "https://10.100.5.238/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testERMSTESTCASEWEBDRIVER() throws Exception {
package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class LOGIN {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "https://10.100.5.238/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testLOGIN() throws Exception {
    driver.get(baseUrl + "/NewERMS/Default.aspx");
    assertEquals("FinTrak ERMS", driver.getTitle());
    driver.findElement(By.id("btnLout")).click();
    assertEquals("Fintrak ERMS | User Login", driver.getTitle());
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("000000");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("seyi.akingbade1");
    driver.findElement(By.id("btnSubmit")).click();
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("Your login attempt was not successful. Please try again.".equals(driver.findElement(By.id("FailureText")).getText())) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    try {
      assertEquals("Your login attempt was not successful. Please try again.", driver.findElement(By.id("FailureText")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("000000");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("seyi.akingbade");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("0000000");
    driver.findElement(By.id("btnSubmit")).click();
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("Your login attempt was not successful. Please try again.".equals(driver.findElement(By.id("FailureText")).getText())) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    try {
      assertEquals("Your login attempt was not successful. Please try again.", driver.findElement(By.id("FailureText")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("000000");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("seyi.akingbade1");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("0000000");
    driver.findElement(By.id("btnSubmit")).click();
    for (int second = 0;; second++) {
    	if (second >= 60) fail("timeout");
    	try { if ("Your login attempt was not successful. Please try again.".equals(driver.findElement(By.id("FailureText")).getText())) break; } catch (Exception e) {}
    	Thread.sleep(1000);
    }

    try {
      assertEquals("Your login attempt was not successful. Please try again.", driver.findElement(By.id("FailureText")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("000000");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("seyi.akingbade");
    driver.findElement(By.id("btnSubmit")).click();
    driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_RadPanelBar1']/ul/li/a/span/span[2]")).click();
    driver.findElement(By.linkText("User")).click();
    driver.findElement(By.xpath("//div[@id='ctl00_ctl00_ContentPlaceHolder2_RadPanelBar1']/ul/li/div/ul/li/div/ul/li/a/span/span[2]")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
